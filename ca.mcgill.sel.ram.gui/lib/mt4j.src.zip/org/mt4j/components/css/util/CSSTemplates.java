package org.mt4j.components.css.util;

public class CSSTemplates {
	
	public static String REDSTYLE = "templates/redstyle.css";
	public static String MATRIXSTYLE = "templates/matrixstyle.css";
	public static String WHITESTYLE = "templates/whitestyle.css";
	public static String GREENSTYLE = "templates/greenstyle.css";
	public static String BLUESTYLE = "templates/bluestyle.css";
	public static String BLACKTEXTONWHITE = "templates/blackTextOnWhite.css";
	

	
	
	
}
