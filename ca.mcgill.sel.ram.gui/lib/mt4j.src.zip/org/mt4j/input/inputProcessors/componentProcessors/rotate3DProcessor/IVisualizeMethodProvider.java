package org.mt4j.input.inputProcessors.componentProcessors.rotate3DProcessor;


public interface IVisualizeMethodProvider {
	
	public void visualize(Cluster3DExt cluster);

}
